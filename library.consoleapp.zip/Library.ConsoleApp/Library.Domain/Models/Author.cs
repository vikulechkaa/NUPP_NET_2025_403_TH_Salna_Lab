﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Domain.Models;

public class Author
{
    public int Id { get; set; }
    public string FullName { get; set; } = string.Empty;

    // 1-to-many
    public List<Book> Books { get; set; } = new();
}

