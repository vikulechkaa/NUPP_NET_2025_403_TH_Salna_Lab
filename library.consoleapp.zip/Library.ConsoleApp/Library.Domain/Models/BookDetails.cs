﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Domain.Models;

public class BookDetails
{
    public int Id { get; set; }                 // зробимо PK == FK до Book
    public int Pages { get; set; }
    public string Isbn { get; set; } = string.Empty;

    public Book? Book { get; set; }
}

