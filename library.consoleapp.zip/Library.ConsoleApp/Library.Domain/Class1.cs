﻿namespace Library.Domain
{
    public class Class1
    {

    }
}
