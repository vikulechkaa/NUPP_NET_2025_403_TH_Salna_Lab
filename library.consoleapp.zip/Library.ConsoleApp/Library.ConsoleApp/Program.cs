﻿using System.Text;
using Library.Domain.Models;
using Library.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

#region Encoding
Console.OutputEncoding = Encoding.UTF8;
Console.InputEncoding = Encoding.UTF8;
#endregion

#region DbContext
var options = new DbContextOptionsBuilder<LibraryContext>()
    .UseSqlite("Data Source=library.db")
    .Options;

using var context = new LibraryContext(options);
await context.Database.MigrateAsync();
#endregion

#region Seed data (якщо БД порожня)
if (!context.Authors.Any())
{
    var author = new Author
    {
        FullName = "Михайло Коцюбинський",
        Books = new List<Book>
        {
            new Book
            {
                Title = "Тіні забутих предків",
                Details = new BookDetails
                {
                    Pages = 240,
                    Isbn = "978-0000000000"
                }
            }
        }
    };

    context.Authors.Add(author);
    await context.SaveChangesAsync();
}
#endregion

#region Output
Console.Clear();
PrintHeader();

var authors = await context.Authors
    .Include(a => a.Books)
    .ThenInclude(b => b.Details)
    .ToListAsync();

foreach (var author in authors)
{
    PrintAuthor(author);
}
#endregion

Console.WriteLine("\nНатисніть будь-яку клавішу для виходу...");
Console.ReadKey();

#region UI helpers
void PrintHeader()
{
    Console.WriteLine("===============================================");
    Console.WriteLine("                 БІБЛІОТЕКА");
    Console.WriteLine("   Entity Framework Core + Repository Pattern");
    Console.WriteLine("===============================================\n");
}

void PrintAuthor(Author author)
{
    Console.WriteLine("👤 Автор");
    Console.WriteLine($"   Імʼя : {author.FullName}");
    Console.WriteLine($"   Id   : {author.Id}\n");

    foreach (var book in author.Books)
    {
        PrintBook(book);
    }

    Console.WriteLine("-----------------------------------------------\n");
}

void PrintBook(Book book)
{
    Console.WriteLine("   📘 Книга");
    Console.WriteLine($"      Назва : {book.Title}");
    Console.WriteLine($"      Id    : {book.Id}");

    if (book.Details != null)
    {
        Console.WriteLine("      📄 Деталі");
        Console.WriteLine($"         Сторінок : {book.Details.Pages}");
        Console.WriteLine($"         ISBN     : {book.Details.Isbn}");
    }

    Console.WriteLine();
}
#endregion
