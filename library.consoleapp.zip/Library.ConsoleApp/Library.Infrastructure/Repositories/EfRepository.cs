﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Library.Infrastructure.Data;

namespace Library.Infrastructure.Repositories;

public class EfRepository<T> : IRepository<T> where T : class
{
    private readonly LibraryContext _context;
    private readonly DbSet<T> _set;

    public EfRepository(LibraryContext context)
    {
        _context = context;
        _set = _context.Set<T>();
    }

    public async Task<T?> GetByIdAsync(int id) => await _set.FindAsync(id);

    public async Task<IEnumerable<T>> GetAllAsync() => await _set.ToListAsync();

    public async Task AddAsync(T entity) => await _set.AddAsync(entity);

    public Task Update(T entity)
    {
        _set.Update(entity);
        return Task.CompletedTask;
    }

    public Task Delete(T entity)
    {
        _set.Remove(entity);
        return Task.CompletedTask;
    }
}