﻿namespace Library.Infrastructure
{
    public class Class1
    {

    }
}
