﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Library.Domain.Models;
using Microsoft.EntityFrameworkCore;

namespace Library.Infrastructure.Data;

public class LibraryContext : DbContext
{
    public DbSet<Author> Authors => Set<Author>();
    public DbSet<Book> Books => Set<Book>();
    public DbSet<BookDetails> BookDetails => Set<BookDetails>();

    public LibraryContext(DbContextOptions<LibraryContext> options) : base(options) { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Author 1..* Books
        modelBuilder.Entity<Author>()
            .HasMany(a => a.Books)
            .WithOne(b => b.Author)
            .HasForeignKey(b => b.AuthorId)
            .OnDelete(DeleteBehavior.Cascade);

        // Book 1..1 BookDetails (Table-per-Type можна, але 1-1 простіше та підходить)
        modelBuilder.Entity<Book>()
            .HasOne(b => b.Details)
            .WithOne(d => d.Book)
            .HasForeignKey<BookDetails>(d => d.Id); // PK==FK

        // Додаткові обмеження
        modelBuilder.Entity<Author>()
            .Property(a => a.FullName)
            .HasMaxLength(200)
            .IsRequired();

        modelBuilder.Entity<Book>()
            .Property(b => b.Title)
            .HasMaxLength(200)
            .IsRequired();

        modelBuilder.Entity<BookDetails>()
            .Property(d => d.Isbn)
            .HasMaxLength(20);

        base.OnModelCreating(modelBuilder);
    }
}
