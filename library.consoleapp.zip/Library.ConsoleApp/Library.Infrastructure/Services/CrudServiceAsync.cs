﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Library.Infrastructure.Data;
using Library.Infrastructure.Repositories;

namespace Library.Infrastructure.Services;

public class CrudServiceAsync<T> : ICrudServiceAsync<T> where T : class
{
    private readonly IRepository<T> _repo;
    private readonly LibraryContext _context;

    public CrudServiceAsync(IRepository<T> repo, LibraryContext context)
    {
        _repo = repo;
        _context = context;
    }

    public async Task<bool> CreateAsync(T element)
    {
        await _repo.AddAsync(element);
        return true;
    }

    public async Task<T?> ReadAsync(int id) => await _repo.GetByIdAsync(id);

    public async Task<IEnumerable<T>> ReadAllAsync() => await _repo.GetAllAsync();

    public async Task<IEnumerable<T>> ReadAllAsync(int page, int amount)
    {
        if (page < 1) page = 1;
        if (amount < 1) amount = 10;

        // Pagination без LINQ в репозиторії — швидко через контекст
        return _context.Set<T>()
            .Skip((page - 1) * amount)
            .Take(amount)
            .ToList();
    }

    public async Task<bool> UpdateAsync(T element)
    {
        await _repo.Update(element);
        return true;
    }

    public async Task<bool> RemoveAsync(T element)
    {
        await _repo.Delete(element);
        return true;
    }

    public async Task<bool> SaveAsync()
    {
        await _context.SaveChangesAsync();
        return true;
    }
}
