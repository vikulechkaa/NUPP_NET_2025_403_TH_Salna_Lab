﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Library.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace Library.Infrastructure.Data;

public class LibraryContextFactory
    : IDesignTimeDbContextFactory<LibraryContext>
{
    public LibraryContext CreateDbContext(string[] args)
    {
        var optionsBuilder = new DbContextOptionsBuilder<LibraryContext>();

        // SQLite — простий ідеальний для лаби
        optionsBuilder.UseSqlite("Data Source=library.db");

        return new LibraryContext(optionsBuilder.Options);
    }
}
